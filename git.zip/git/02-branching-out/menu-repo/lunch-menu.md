# Galactic Gastronomy: A Sci-Fi Feast for the Senses
## Lunch time menu

- The Alien Burger - £10.99

Our signature burger with a patty made from extraterrestrial meat, topped with green cheese and served on a black bun.

- The Cyborg Burger - £12.99

A burger made with a blend of beef and machine parts, topped with metallic cheese and served on a silver bun.

- The Time Traveler Burger - £11.99

A burger with a patty made from prehistoric meat, topped with futuristic toppings like freeze-dried tomatoes and served on a holographic bun.

- The Space Cowboy Burger - £13.99 

A burger made with space-aged beef, topped with crispy space bacon and served on a cosmic bun.

- The Robot Burger - £10.99

A vegetarian burger made with plant-based meat and served on a metallic bun.

- The Mutant Burger - £14.99

A burger made with genetically modified meat, topped with radioactive cheese and served on a mutant bun.

> All burgers come with a side of galactic fries and a drink. We also have a selection of desserts, including our famous Warp Drive Chocolate Cake for £6.99. Enjoy your meal and don't forget to come back and visit us in the future!