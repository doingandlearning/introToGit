# Branching Out

This section is focused on getting comfortable with creating branches, switching between them and merging them.

The three exercises are short and hopefully draw out the key points:

- How to create and switch between branches
- How to merge branches
- How to resolve merge conflicts

I've begun a menu repository for you to start with. 

Feel free to experiment working through these exercises using the command line and Gitlens inside of VS Code. If you're working in VS Code, it will work better if you open the `menu-repo` folder in it's own window of VSCode. This course has multiple repositories and VS Code sometimes struggles to handle that when working.

As before, there are bullet notes at the end of the section.

## Exercise 1: Creating and switching to a new branch

1. Create a new branch called "updated-lunch-menu" using git branch.
2. Switch to the new branch using git switch.
3. Add a new lunch dish file and commit the changes.
4. Switch back to the main branch and confirm the changes aren't there.
5. We've changed our minds - delete the branch.

## Exercise 2: Merging branches

1. Create a new branch called "adding-breakfast-menu" using git branch.
2. Switch to the new branch using git switch.
3. Create a breakfast menu and add a few dishes. Commit the changes.
4. Switch back to the main branch using git switch.
5. Merge the changes from the "adding-breakfast-menu" branch into the main branch using `git merge adding-breakfast-menu`.
6. Delete the feature branch.

## Exercise 3: Resolving merge conflicts

1. Create a new branch called "updating-breakfast-menu" using git branch.
2. Switch to the new branch using git switch.
3. Make some changes to the breakfast menu and commit the changes.
4. Switch back to the main branch using git switch.
5. Make some different changes to the breakfast menu while on main and commit the changes.
6. Merge the changes from the "updating-breakfast-menu" branch into the main branch using git merge updating-breakfast-menu.
7. Resolve the merge conflict and commit the changes.


## Section Summary

- Branches are one of Git’s best features. Branches allow you to work on multiple tasks at the same time.
- When working in Git, you are always working on a branch. Every repository starts with a branch and defaults to the name main.
- The main branch is not special in any way. It’s no different than any other branch you create. You can rename or even delete the main branch.
- The primary command to work with branches is git branch. You can use git branch to create, list, and delete branches.
- To create a branch called update-profile, supply the name to git branch like so: git branch update-profile
- git branch allows you to create branches, but to start using the new branch, use the git switch command. Supply it with the name of the branch you wish to start using, like so: git switch update-profile
- Think of a branch as a sticky note that contains the branch name and the commit ID of the last commit on that branch.
- Every time you make a commit on a branch, Git updates the sticky note that represents that branch, giving it the new commit ID. This is how a branch “moves.”
- Since branches always point to commits, they offer an easy way to create other branches.
- Whenever you switch branches, Git rewrites the working directory to reflect the state captured in the latest commit on that branch.
- In a typical workflow, some branches (by convention) are treated as “integration” branches to collect the work done in other branches.
- In contrast, day-to-day work is done in “feature” branches. Each feature branch is to be used for one thing and one thing only: for example, to introduce a new feature, or fix a bug.
- To combine the work you’ve done in an integration branch, you merge the feature branch into the integration branch.
- The easiest kind of merge is called a “fast-forward merge,” in which one branch simply “catches up” with another branch.
- The other kind of merge is when you merge two branches that have diverged from one another, in which case Git will create a merge commit
- A merge commit is like any other commit, except it’s created by Git and has not one but two parents—the first parent is the latest commit on the integration branch, and the second parent is the latest commit on the feature branch.
- Occasionally, the same line in the same file has been modified in the two branches being merged, causing a merge conflict. Git relies on you to resolve the merge conflict.
- You can delete a branch using the git branch command, along with the -d (or --delete) flag.
- If you attempt to delete a branch that has not been merged yet, Git will error out. If you are absolutely sure you want to delete an unmerged branch, you’ll have to use the -D (uppercase “D”) flag with the git branch command.
- A branch is always based on a commit. If you know the ID of the commit you want to use as the basis for a branch, you can supply it to the git branch command: git branch branch-name commit-ID

## Possible Gitflow diagrams

General workflow:

![Alt text](images/Release%20branches.svg)

But sometimes we need a hotfix!

![Alt text](images/Hotfix%20branches.svg)