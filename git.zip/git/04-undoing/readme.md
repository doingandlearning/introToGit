# Undoing

In this section, we are exploring how step back changes when we've changed our minds. There are a number of options - some of them destructive and some of them not.

We're going to be working in the `office-party` repo. Remember, if you're using VS Code rather than the command line, it works better to open this folder in a separate VS Code window.

As normal, the summary notes will be at the end.

## Exercise 1: Using git restore to undo changes

1. Add a new game to `games.md` file and add the changes to the index. Use `git status` to check on the current status.
2. Remove an item from the `food.md` file but don't add it yet. Use `git status` to check on the current state of the repo.
3. Use `git restore food.md` to undo the changes in the working directory that haven't been added to the index. Again, check in with `git status`.
4. Use `git restore --staged games.md` to remove the changes from the index.
5. Now, `git restore games.md` to remove the changes from the working directory.

## Exercise 2: Using git rm to delete files

1. Create a new file for drinks and add it to the index.
2. Make a new commit to add this file.
3. You've decided not to have a drink file, so use git rm <filename> to delete the file from the working directory and the index.
4. `git status` shows you that although the file is now gone from our working directory and index, there is a different in our object store. We need to make a commit to record the deletion. Commit the deletion with git commit -m "Delete file"

## Exercise 3: Editing commit messages with git commit --amend

1. Update the food menus and make a commit with a message. Make it have a typo.
2. Use git commit --amend to edit the commit message and fix the typo.
3. Verify the changes with git log or git log --oneline.

## Exercise 4: Using git reset to undo commits

1. Create a new branch in your repository to make changes on. You can use the command git branch <new-branch-name> to do this. Make sure to switch to the new branch using the command git checkout <new-branch-name>.
2. Make changes to the files in your repository. For example, you might update the food or games files, or modify the invite files to include additional details or instructions. Save your changes when you're finished.
3. Stage your changes by running the command git add . This will stage all the changes you made.
4. Commit your changes using the command git commit -m "Description of your changes".
5. Check the status of your repository using the command git status. This will confirm that your changes have been committed to your branch.
6. Now, suppose you want to undo the last commit you made. You can use git reset to do this. The command git reset HEAD~1 will undo the last commit you made and move the changes back to the staging area. This is useful if you want to make additional changes to the files before committing again.
7. If you want to completely remove the changes you made in the last commit, you can use the --hard option with git reset. This will permanently delete the changes you made, so be careful when using this option. The command `git reset --hard HEAD~1` will undo the last commit and delete the changes you made.
8. Finally, if you want to undo all the changes you made and go back to the last commit on your branch, you can use the command `git reset --hard HEAD`. This will delete all the changes you made and restore your repository to the state it was in at the last commit.

## Exercise 5: Using git revert to undo commits

1. Use git log to identify the commit you deleted the drinks menu.
2. Use git revert <commit> to create an "anti-commit" that undoes the changes introduced by the specified commit.
3. Commit the anti-commit with a message and verify the changes with git log or git log --oneline.


## Section Summary

- Git offers you several ways to undo your changes.
- The git restore command allows you to undo changes to one or more files—both in the working directory and the index. You can supply git restore with a list of file paths.
- The git restore command, by default, undoes changes in the working directory by replacing them with the version of the file that was last added to the index.
- To undo changes to files that have been already added to the index, you can also use the git restore command. However, you will need to supply it with the --staged flag.
- The git restore --staged command will replace the contents of the files in the index with the version that was last committed.
- You can delete files that you previously committed to Git with the git rm command.
- The git rm command, like the git restore command, takes a list of file paths. It then removes the files from the working directory and the index.
- You are still required to make a commit to record the fact that you deleted one or more files. That is, removing files is a two-step process—git rm removes the files from the working directory and the index, and the subsequent commit records the deletion.
- You can edit commit messages with the git commit command along with the --amend flag.
- You should only amend the tips of branches.
- When you amend a commit, you are not actually changing a commit. Git records a new commit with the new commit message and replaces the previous commit in your commit history. Git will eventually delete the older commit.
- Git allows you to rename branches by using the git branch command with the -m (or --move) flag.
- The commit you are on is referred to as HEAD. HEAD is a reference to a commit.
- HEAD is how Git knows which branch you are on; it’s a lot like the pin in a map that shows your location. HEAD is updated every time you switch or merge branches.
- The commit that HEAD points to will be the parent of the next commit in the repository.
- Git offers two operators to reference ancestor commits relative to HEAD. You have the tilde (~) operator to reference parents of the current commit. HEAD~2, for example, takes you back two generations: it represents the grandparent of the current commit.
- You can use the caret (^) operator to reference the parents of a merge commit. HEAD^1 points to the first parent, and HEAD^2 points to the second.
- The tilde and caret operators make it easier to supply commits to commands like git diff, saving you from having to copy-paste commit IDs.
- Git offers two different ways to undo commits. The git reset command moves the HEAD and the branch “sticky note” to a different commit.
- The git reset command has three different modes—soft, mixed, and hard. Each one has a different effect on the changes that were recorded in the commit that was undone.
- Be warned! The git reset command in “hard” mode is destructive: if you use it, you will lose your changes. So don’t use it.
- git reset allows you to “time travel,” in effect, because it moves you to a previous commit.
- Another way to undo a commit is with the git revert command, which creates an “anti-commit”—a commit that introduces a set of changes that are the exact opposite of the commit that you wish to undo.