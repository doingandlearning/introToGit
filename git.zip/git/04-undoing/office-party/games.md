# Games for the party

1. Two Truths and a Lie - Each person shares three statements about themselves, two of which are true and one of which is a lie. Other participants must guess which statement is the lie.
2. Office Charades - Teams take turns acting out office-related words or phrases while their teammates guess what they are.
3. Name That Tune - A music-based game in which participants listen to a short clip of a song and try to guess the title and artist.
4. White Elephant Gift Exchange - Each person brings a wrapped, unmarked gift and players take turns choosing a gift from the pile or "stealing" one that someone else has already opened.
5. Office Bingo - Create bingo cards with items commonly found in the office (e.g. "coffee spill," "overdue report," "phone ringing off the hook," etc.) and play a few rounds of bingo.
6. Trivia Game - Create a trivia game with questions related to the office, industry, or pop culture.
7. Minute to Win It - A series of timed challenges where participants have one minute to complete a task such as stacking cups, building a tower with office supplies, or bouncing ping-pong balls into cups.
8. Escape Room - Create a mini-escape room in the office where participants must solve a series of puzzles and clues to "escape" within a set time limit.
9. Who Am I? - Each person writes the name of a famous person on a sticky note and sticks it to the forehead of the person next to them. Players take turns asking yes/no questions to try to figure out who they are.
10. Pictionary - A classic drawing-based game where participants take turns drawing pictures and their teammates try to guess what the picture is of.