# Food

1. Haggis balls
2. Scottish smoked salmon with gluten-free crackers
3. Scottish oatcakes with vegan pate
4. Vegan scotch broth 
5. Gluten-free vegetable bridies 
6. Roast vegetables with a vegan dip (e.g. hummus or baba ganoush)
7. Gluten-free quinoa salad with roasted vegetables
8. Vegan lentil and vegetable curry
9. Cullen skink 
10. Gluten-free and vegan shortbread