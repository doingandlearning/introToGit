# Looking Around

In this section, we looked at a few tools to investigate your Git repositories - namely, `git log` and `git diff`.

I've provided a Starfleet Resume that has some changes going on.

## Exercise 1: Familarise yourself with the repo

1. What branches are there on this repo?
2. Switch between them - can you notice any difference in the files as you do that?


## Exercise 2: Using git log to view commit history

1. Use `git log` to view the commit history for the current branch. Make sure you can identify the author, the commit id, the date and the commit message.
2. Switch to another branch and have a look at the log there. Has it changed?
3. We looked at a few flags. Try using the `--oneline` flag with `git log`.
4. Use the `--graph` and `--all` flags to view the commit history for all branches in a graphical format. Where is the `HEAD`? What happens to the `HEAD` as you change branches?

## Exercise 2: Using git diff to view changes

1. Make some changes to the resume in the working directory.
2. Use git diff to view the changes between the working directory and the index. Can you identify the hunk header? What information is it telling you?
3. Stage your changes by adding them to the index. What do you expect the `git diff` to show now?
4. Use git diff --cached to view the changes between the index and the object database.
5. Use `git diff branch1..branch2` to view the differences between two branches.
6. Use `git log` to find two commit ID's. Now use `git diff commit1..commit2` to view the differences between these two commits. Remember, you don't need to use the whole commit ID, just enough to be unique in this repository.



## Section summary

- The git log command shows us the commit history of our repository.
- The git log command, by default, lists all the commits, along with the commit metadata, for the current branch.
- Flags like --abbrev-commit, --pretty with the oneline option, or the --oneline flag make it easier to visualize the commit history of a single branch.
- Using the --all and --graph flags with the git log command allow us to visualize the history of every branch in our repository.
- Git tracks changes—between the working directory and the index, and index and the object database.
- To find out what changed between the index and the working directory, use the git diff command. The default behavior of the git diff command is to compare the index and the working directory.
- The output of the git diff command starts by telling you which file’s differences are currently being displayed. Typically, one set of changes is prefixed with “a,” and the other is marked by “b”: diff --git a/resume.md b/resume.md
- This is followed by a legend that tells how the log output will differentiate between lines that exist in “a” versus “b”:
        --- a/resume.md
        +++ b/resume.md
- The legend is followed by a series of “hunks” that allow you to see the changes in bite-sized pieces. Each hunk has lines prefixed with a minus (meaning it comes from the version of the file prefixed with “a/”), or a plus (meaning it is present in the file prefixed with version “b/”).
- Git will display as many, and only as many, hunks as needed to display all the differences. This makes it easier to compare large files.
- The --cached (or --staged) flag for the diff command allows us to compare the changes that we last committed: that is, the changes in Git’s object database with the changes added to the index.
- We can supply the git diff command with two branch names. In such a case, git diff will compare the differences between the “tips” of the two branches.
- The git diff command is always comparing two sets of changes, which can be visualized by a Venn diagram. The first argument is the set on the left (always indicated by “a/”) and prefixed with a minus (“-”). The second argument is the set of the right, indicated by “b/”, and prefixed with a “+”.
- Swapping the order of the arguments swaps the left-hand and right-hand sides of the Venn diagram.
- We can use the git log command to identify commit IDs, which in turn we can supply to the git diff command to compare two disparate commits.