# Getting started

This first section was all about getting familar with Git on the command line and in VS Code.

The first exercise here is a definition and knowledge check-in. Have a skim but feel free to move on if you're happy. 

The second and third are more practical. We're using four of the git subcommands here:

- git init
- git add
- git commit
- git status

By the end of this section, you should be happy with what each of these do and how to use them.

There is a bullet note summary at the end of this file.

## Exercise 1: Quick definitions

What do each of these commands do?

- pwd
- cd
- mkdir
- ls

How about these git subcommands?

- git init
- git add
- git commit
- git status

What about these words?

- repository
- commit
- index
- object database

## Exercise 2: Getting around

In this exercise, we are creating a directory, initialising it as a Git repository and then creating some commits.

As you work through the steps, think about how files (and parts of files) are moved through the Untracked -> Unmodified -> Modified -> Staged journey.

1.  Create a new directory
2.  Initialise a git repository
3.  Check the status of the repository
4.  Create a new file with some content
5.  Check the status of the repository
6.  Add the file to the index
7.  Check the status of the repository
8.  Make a commit
9.  Check the status of the repository
10. Update the file and save
11. Check the status of the repository
12. Stage the file
13. Check the status of the repository
14. Make a commit
15. Check the status of the repository

## Exercise 3: Do it again!

Work through the exercise above with the VS Code plugin.

The first two steps will still need to be on the command line.



## Section Summary

![Alt text](images/tracking-journey.png)

- A version control system like Git allows you to store snapshots of your work.
- Git is much more than a tool that allows you to record snapshots. Git allows us to confidently collaborate with other team members.
- Using Git effectively requires you to be comfortable with the command line.
- The command line offers a slew of other capabilities, including creating and navigating directories and listing files.
- Git is available as an executable, which you install, and it makes Git available to use in the command line with the name git.
- Once you install Git, you need to tell Git your full name and your email address. Git will use this whenever you use Git to take a snapshot of your work.
- If you want Git to manage the files for any project, we have to initialize a Git repository at the root level of the project.
- To initialize Git you use the init command, like so: git init
- The result of initializing a new Git repository is that Git will create a hidden folder called .git in the directory where you ran the git init command. This hidden folder is used by Git to store your snapshots, as well as some configuration for Git itself.
- Any directory that is managed by Git is referred to as the working directory.
- Git, by design, has an index, which acts as a “staging area.” To add files to the index, you use the git add <filename> command.
- Committing in Git translates to taking a snapshop of the changes that were stored in the index. The command to create a commit is git commit, which requires that you supply it with a commit message to describe the changes you are commiting, using the -m (or --message) flag:
- git commit -m “some message”
- Every file in the working directory is assigned one or more states.
- A brand new file added to the working directory is marked as “untracked,” which suggests that Git does not know about this file.
- Adding a new file to Git’s index does two things—it marks the file as being “tracked” and creates a copy of that file into the index.
- When you make a commit, Git creates a copy of the files in the index and stores them in the object database. It also creates a commit object that records metadata about the commit, including a pointer to the files that were just stored, the author name and email, and the time the commit was made, as well as the commit message.
- Every commit in Git is identified by a unique identifier, refererred to as the commit ID.
- At any time you can ask Git for the status of the files in the working directory and the Git repository, using the git status command.
- Every commit except the initial commit in Git stores the commit ID of the commit that appeared just before it, thus creating a string of commits, like leaves on a branch.
- This string of commits is referred to as the commit history.